# 📱 Catatan Keuangan - Expo App

Aplikasi catatan keuangan lengkap berbasis React Native dengan Expo dan SQLite.

## ✨ Fitur Lengkap

- **Dashboard** — Ringkasan saldo, pemasukan, pengeluaran, grafik bulanan, transaksi terbaru
- **Transaksi** — Tambah, edit, hapus, cari, filter transaksi dengan kategori
- **Laporan** — Grafik bar bulanan, pie chart kategori, margin keuntungan, overflow/cash flow
- **Kategori** — Kelola kategori pemasukan & pengeluaran dengan ikon dan warna custom
- **Database SQLite** — Data tersimpan permanen di perangkat (offline first)
- **Dark Mode UI** — Desain modern gelap yang nyaman di mata

---

## 🚀 Tutorial Instalasi & Menjalankan di VSCode

### Prasyarat

Pastikan sudah terinstall:

| Tools | Download |
|-------|----------|
| Node.js (v18+) | https://nodejs.org |
| Git | https://git-scm.com |
| VSCode | https://code.visualstudio.com |
| Expo Go (HP) | Play Store / App Store |

### Langkah 1 — Buka project di VSCode

```bash
# Extract folder FinanceApp yang sudah didownload
# Buka VSCode, lalu File > Open Folder > pilih folder FinanceApp
```

### Langkah 2 — Install dependencies

Buka Terminal di VSCode (Ctrl+` atau View > Terminal):

```bash
npm install
```

Tunggu hingga selesai (±2-5 menit tergantung koneksi).

### Langkah 3 — Jalankan development server

```bash
npx expo start
```

Akan muncul QR code di terminal.

### Langkah 4 — Buka di HP dengan Expo Go

1. Install **Expo Go** di HP (Android/iOS)
2. Pastikan HP dan laptop **terhubung ke WiFi yang sama**
3. **Android**: Scan QR code dengan app Expo Go
4. **iOS**: Scan QR code dengan Camera bawaan iPhone

> **Catatan**: Kalau QR code tidak bisa di-scan, coba tekan `w` untuk buka di browser, atau `a` untuk Android emulator.

---

## 📋 Perintah Berguna

```bash
# Jalankan di Android (perlu Android Studio / emulator)
npx expo start --android

# Jalankan di iOS (perlu Xcode, Mac only)
npx expo start --ios

# Reset cache (jika ada error aneh)
npx expo start --clear

# Bersihkan node_modules dan install ulang
rm -rf node_modules && npm install
```

---

## 🔧 Ekstensi VSCode yang Direkomendasikan

Install ekstensi ini di VSCode untuk pengalaman terbaik:

1. **ESLint** — `dbaeumer.vscode-eslint`
2. **Prettier** — `esbenp.prettier-vscode`
3. **React Native Tools** — `msjsdiag.vscode-react-native`
4. **TypeScript** — `ms-vscode.vscode-typescript-next`

---

## 🏗️ Build untuk Production

### Langkah 1 — Install EAS CLI

```bash
npm install -g eas-cli
```

### Langkah 2 — Login ke Expo

```bash
eas login
# Buat akun di https://expo.dev kalau belum punya
```

### Langkah 3 — Konfigurasi project

```bash
eas build:configure
```

### Langkah 4 — Build APK (Android Preview)

```bash
# Build APK untuk testing (bisa langsung install di HP)
eas build --platform android --profile preview
```

### Langkah 5 — Build AAB (Android Production / Play Store)

```bash
# Build untuk upload ke Google Play Store
eas build --platform android --profile production
```

### Langkah 6 — Build iOS (butuh Mac + Apple Developer Account)

```bash
eas build --platform ios --profile production
```

> Build dijalankan di cloud Expo, jadi tidak perlu install Android Studio atau Xcode untuk build dasar. Hasilnya bisa didownload dari dashboard https://expo.dev

---

## 📁 Struktur Project

```
FinanceApp/
├── app/
│   ├── _layout.tsx          ← Root layout, inisialisasi DB
│   ├── (tabs)/
│   │   ├── _layout.tsx      ← Navigasi tab bawah
│   │   ├── index.tsx        ← Dashboard
│   │   ├── transactions.tsx ← Daftar transaksi
│   │   ├── reports.tsx      ← Laporan & grafik
│   │   └── categories.tsx   ← Manajemen kategori
│   └── transaction/
│       ├── add.tsx          ← Form tambah transaksi
│       ├── edit.tsx         ← Form edit transaksi
│       └── detail.tsx       ← Detail transaksi
├── lib/
│   ├── database.ts          ← Semua operasi SQLite
│   └── utils.ts             ← Helper, format, warna
├── assets/                  ← Icon & splash screen
├── app.json                 ← Konfigurasi Expo
├── eas.json                 ← Konfigurasi build EAS
└── package.json             ← Dependencies
```

---

## 🎨 Mengganti Nama & Ikon Aplikasi

Edit file `app.json`:

```json
{
  "expo": {
    "name": "Nama App Anda",        ← nama di layar HP
    "slug": "nama-app-anda",        ← ID unik (huruf kecil, pakai -)
    ...
    "android": {
      "package": "com.nama.app"     ← package ID unik
    }
  }
}
```

Untuk ikon, ganti file di folder `assets/`:
- `icon.png` — 1024×1024px PNG
- `adaptive-icon.png` — 1024×1024px PNG  
- `splash-icon.png` — minimal 200×200px PNG

Generate otomatis di: https://expo.dev/tools/icon-generator

---

## 🌐 Menambah Mata Uang Lain

Edit file `lib/utils.ts`, fungsi `formatCurrency`:

```typescript
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',  // ← ganti: 'USD', 'EUR', 'MYR', dll
    ...
  }).format(amount);
};
```

---

## ❓ Troubleshooting

**Error: "Unable to resolve module expo-sqlite"**
```bash
npm install expo-sqlite
npx expo install expo-sqlite
```

**QR code tidak bisa di-scan**
- Pastikan HP dan laptop satu WiFi
- Coba gunakan tunnel: `npx expo start --tunnel`

**Metro bundler stuck**
```bash
npx expo start --clear
```

**Error "Cannot find module '@/lib/database'"**
- Pastikan `tsconfig.json` ada dan berisi paths `"@/*": ["./*"]`

---

## 📞 Teknologi yang Digunakan

| Teknologi | Versi | Fungsi |
|-----------|-------|--------|
| Expo | ~53.0 | Framework React Native |
| Expo Router | ~4.0 | Navigasi file-based |
| Expo SQLite | ~15.0 | Database lokal |
| React Native | 0.79 | UI Framework |
| TypeScript | ~5.8 | Type safety |
| @expo/vector-icons | ^14 | Icon set |

---

Selamat menggunakan! 🎉
