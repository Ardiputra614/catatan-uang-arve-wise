import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import * as SplashScreen from 'expo-splash-screen';
import { useFonts } from 'expo-font';
import { initDatabase } from '@/lib/database';
import Toast from 'react-native-toast-message';
import { View } from 'react-native';

SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded] = useFonts({});

  useEffect(() => {
    const setup = async () => {
      try {
        await initDatabase();
      } catch (e) {
        console.error('DB init error:', e);
      } finally {
        if (loaded) {
          await SplashScreen.hideAsync();
        }
      }
    };
    setup();
  }, [loaded]);

  if (!loaded) return null;

  return (
    <View style={{ flex: 1 }}>
      <StatusBar style="light" backgroundColor="#0F172A" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        <Stack.Screen
          name="transaction/add"
          options={{ headerShown: false, presentation: 'modal' }}
        />
        <Stack.Screen
          name="transaction/edit"
          options={{ headerShown: false, presentation: 'modal' }}
        />
        <Stack.Screen
          name="transaction/detail"
          options={{ headerShown: false, presentation: 'modal' }}
        />
      </Stack>
      <Toast />
    </View>
  );
}
